<?php
class etiqueta5 {
    function html($hoja,$s1,$s2c) {
	    ?>
		<style>
			table {
	           font-family: Arial,Helvetica Neue,Helvetica,sans-serif;
            }
		</style>
		<table BORDER CELLPADDING=0 CELLSPACING=0 style="width: 100%;">
              <tr>
                <td width="50%">
                	<b><?=@utf8_decode($s1['nombre']);?></b><br>
                	<b><?=@utf8_decode($s1['nocas']);?></b><br>
                	<?php
                	foreach ($s2c as $img){
                	    echo '<img src="'.base_url().'public/images/pictogramas/'.$img['imagen'].'" width="35" height="35"/>';
                	}
                	?>
                </td>
                <td width="50%">
                	<b><?=@utf8_decode($s1['nombre']);?></b><br>
                	<b><?=@utf8_decode($s1['nocas']);?></b><br>
                	<?php
                	foreach ($s2c as $img){
                	    echo '<img src="'.base_url().'public/images/pictogramas/'.$img['imagen'].'" width="35" height="35"/>';
                	}
                	?>
                </td>
              </tr>
              <tr>
                <td width="50%">
                	<b><?=@utf8_decode($s1['nombre']);?></b><br>
                	<b><?=@utf8_decode($s1['nocas']);?></b><br>
                	<?php
                	foreach ($s2c as $img){
                	    echo '<img src="'.base_url().'public/images/pictogramas/'.$img['imagen'].'" width="35" height="35"/>';
                	}
                	?>
                </td>
                <td width="50%">
                	<b><?=@utf8_decode($s1['nombre']);?></b><br>
                	<b><?=@utf8_decode($s1['nocas']);?></b><br>
                	<?php
                	foreach ($s2c as $img){
                	    echo '<img src="'.base_url().'public/images/pictogramas/'.$img['imagen'].'" width="35" height="35"/>';
                	}
                	?>
                </td>
              </tr>
              <tr>
                <td width="50%">
                	<b><?=@utf8_decode($s1['nombre']);?></b><br>
                	<b><?=@utf8_decode($s1['nocas']);?></b><br>
                	<?php
                	foreach ($s2c as $img){
                	    echo '<img src="'.base_url().'public/images/pictogramas/'.$img['imagen'].'" width="35" height="35"/>';
                	}
                	?>
                </td>
                <td width="50%">
                	<b><?=@utf8_decode($s1['nombre']);?></b><br>
                	<b><?=@utf8_decode($s1['nocas']);?></b><br>
                	<?php
                	foreach ($s2c as $img){
                	    echo '<img src="'.base_url().'public/images/pictogramas/'.$img['imagen'].'" width="35" height="35"/>';
                	}
                	?>
                </td>
              </tr>
              <tr>
                <td width="50%">
                	<b><?=@utf8_decode($s1['nombre']);?></b><br>
                	<b><?=@utf8_decode($s1['nocas']);?></b><br>
                	<?php
                	foreach ($s2c as $img){
                	    echo '<img src="'.base_url().'public/images/pictogramas/'.$img['imagen'].'" width="35" height="35"/>';
                	}
                	?>
                </td>
                <td width="50%">
                	<b><?=@utf8_decode($s1['nombre']);?></b><br>
                	<b><?=@utf8_decode($s1['nocas']);?></b><br>
                	<?php
                	foreach ($s2c as $img){
                	    echo '<img src="'.base_url().'public/images/pictogramas/'.$img['imagen'].'" width="35" height="35"/>';
                	}
                	?>
                </td>
              </tr>
              <tr>
                <td width="50%">
                	<b><?=@utf8_decode($s1['nombre']);?></b><br>
                	<b><?=@utf8_decode($s1['nocas']);?></b><br>
                	<?php
                	foreach ($s2c as $img){
                	    echo '<img src="'.base_url().'public/images/pictogramas/'.$img['imagen'].'" width="35" height="35"/>';
                	}
                	?>
                </td>
                <td width="50%">
                	<b><?=@utf8_decode($s1['nombre']);?></b><br>
                	<b><?=@utf8_decode($s1['nocas']);?></b><br>
                	<?php
                	foreach ($s2c as $img){
                	    echo '<img src="'.base_url().'public/images/pictogramas/'.$img['imagen'].'" width="35" height="35"/>';
                	}
                	?>
                </td>
              </tr>
              <tr>
                <td width="50%">
                	<b><?=@utf8_decode($s1['nombre']);?></b><br>
                	<b><?=@utf8_decode($s1['nocas']);?></b><br>
                	<?php
                	foreach ($s2c as $img){
                	    echo '<img src="'.base_url().'public/images/pictogramas/'.$img['imagen'].'" width="35" height="35"/>';
                	}
                	?>
                </td>
                <td width="50%">
                	<b><?=@utf8_decode($s1['nombre']);?></b><br>
                	<b><?=@utf8_decode($s1['nocas']);?></b><br>
                	<?php
                	foreach ($s2c as $img){
                	    echo '<img src="'.base_url().'public/images/pictogramas/'.$img['imagen'].'" width="35" height="35"/>';
                	}
                	?>
                </td>
              </tr>
              <tr>
                <td width="50%">
                	<b><?=@utf8_decode($s1['nombre']);?></b><br>
                	<b><?=@utf8_decode($s1['nocas']);?></b><br>
                	<?php
                	foreach ($s2c as $img){
                	    echo '<img src="'.base_url().'public/images/pictogramas/'.$img['imagen'].'" width="35" height="35"/>';
                	}
                	?>
                </td>
                <td width="50%">
                	<b><?=@utf8_decode($s1['nombre']);?></b><br>
                	<b><?=@utf8_decode($s1['nocas']);?></b><br>
                	<?php
                	foreach ($s2c as $img){
                	    echo '<img src="'.base_url().'public/images/pictogramas/'.$img['imagen'].'" width="35" height="35"/>';
                	}
                	?>
                </td>
              </tr>
              <tr>
                <td width="50%">
                	<b><?=@utf8_decode($s1['nombre']);?></b><br>
                	<b><?=@utf8_decode($s1['nocas']);?></b><br>
                	<?php
                	foreach ($s2c as $img){
                	    echo '<img src="'.base_url().'public/images/pictogramas/'.$img['imagen'].'" width="35" height="35"/>';
                	}
                	?>
                </td>
                <td width="50%">
                	<b><?=@utf8_decode($s1['nombre']);?></b><br>
                	<b><?=@utf8_decode($s1['nocas']);?></b><br>
                	<?php
                	foreach ($s2c as $img){
                	    echo '<img src="'.base_url().'public/images/pictogramas/'.$img['imagen'].'" width="35" height="35"/>';
                	}
                	?>
                </td>
              </tr>
        </table>
        <br>
		<?php
	}
}
?>
