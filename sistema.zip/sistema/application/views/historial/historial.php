<h2>Historial</h2>
<br>
<div class ="table-responsive">
	<table id="tblHistorial" class="table table-striped table-bordered" width="100%">
		<thead>
	    <tr>
	        <th>Fecha</th>
			<th>Descripcion</th>
	    </tr>
	   	</thead>
	</table>
</div>
